(function( window, $ ) {

    window.app.utils = {};

})( window, jQuery );
