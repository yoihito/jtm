(function( window, $ ) {

    window.app = {};

    window.app.data = {};

})( window, jQuery );
